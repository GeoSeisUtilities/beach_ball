MODULE_NAME = "obspy.io.dmx"
