#!/usr/bin/env python
# -*- coding: utf-8 -*-
MODULE_NAME = "obspy.io.kinemetrics"
