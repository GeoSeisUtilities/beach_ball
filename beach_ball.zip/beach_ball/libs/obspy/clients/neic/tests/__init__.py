# -*- coding: utf-8 -*-
MODULE_NAME = "obspy.clients.neic"
